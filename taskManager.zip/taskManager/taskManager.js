import { LightningElement, wire } from 'lwc';
import Id from "@salesforce/user/Id";
import retrieveTask from '@salesforce/apex/fetchTasks.retrieveTask';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import updateTask from '@salesforce/apex/fetchTasks.updateTask';

import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import { getPicklistValue } from 'lightning/uiObjectInfoApi';
import TASK_OBJECT from '@salesforce/schema/Task';
import STATUS_FIELD from '@salesforce/schema/Task.Status';
const actions = [
    { label: 'View', name: 'view' },
    { label: 'Edit', name: 'edit' },
];
 
const columns = [
    { label: 'Id', fieldName: 'Id' }, 
    { label: 'AssignedTo', fieldName: 'OwnerName', sortable: true  },
    { label: 'Name', fieldName: 'ContactName', sortable: true  },
    { label: 'Due Date', fieldName: 'ActivityDate', sortable: true  },
    { label: 'Subject', fieldName: 'Subject', sortable: true  },
    { label: 'Status', fieldName: 'Status', sortable: true, editable:true
        /*typeAttributes:{
            options:{fieldName : 'StatusOptions'},
            value: {fieldName : 'Status'},
            placeholder: 'Choose Status'
        },*/
      },  
   /* {   label: 'Action',
        type: 'action',
        initialWidth:'50px',
        typeAttributes: { rowActions: actions },
    },*/     
];
 
export default class TaskManager extends NavigationMixin(LightningElement)  {
    userId = Id;
    columns = columns;
    items;
    error;
    datacoll;
    saveDraftValue;
    retrievedTask;
  /*  taskStatus =[];
 
    @wire(getObjectInfo,{objectApiName: TASK_OBJECT})
    taskObjectMetadata;

    @wire(getPicklistValue,{recordTypeId: '$taskObjectMetadata.data.defaultRecordTypeId', fieldApiName: STATUS_FIELD})
    TaskStatusPicklist({data,error}){
        if(data){
            this.taskStatus = data.values;
            this.fetchTasks();
        }else if(error){

        }
    }
    fetchTasks(){
        retrieveTask({ userRecId: Id })
        .then((data) => {
            let currentData = [];
            let option =[];
            for(var key in this.taskStatus){
                option.push({label: this.taskStatus[key].label , value: this.taskStatus[key].value});
            }
            data.forEach((row) => {
                let rowData = {};
                rowData.Id = row.Id;
                rowData.ActivityDate = row.ActivityDate;
                rowData.Subject = row.Subject;
                rowData.Status = row.Status;
                if(row.OwnerId){
                    rowData.OwnerName = row.Owner.Name;
                }
                if(row.WhoId){
                    rowData.ContactName = row.Who.Name; 
                }
                
                currentData.push(rowData);
            });
            this.items = currentData.map((record) => {
                return{
                    ...record,
                    'StatusOptions': option
                }
            });
            //this.items = data;
            this.columns = columns;
            this.error = undefined;
            alert('items '+this.items);
        })
        .catch((error) => {
            this.error = error;
            this.items = undefined;
            this.showToast(this.error, 'Error', 'Error'); //show toast for error
        });
    }*/

    @wire(retrieveTask,{ userRecId: Id })
    wiredTasks(value) {
        this.retrievedTask = value;
        const { data, error} = value;
        if (data) {
            //let data = value.data;
            let currentData = [];
            data.forEach((row) => {
                let rowData = {};
                rowData.Id = row.Id;
                rowData.ActivityDate = row.ActivityDate;
                rowData.Subject = row.Subject;
                rowData.Status = row.Status;
                if(row.OwnerId){
                    rowData.OwnerName = row.Owner.Name;
                }
                if(row.WhoId){
                    rowData.ContactName = row.Who.Name; 
                }
                
                currentData.push(rowData);
            });

            this.items = currentData;
            //this.items = data;
            //this.datacoll = data;
            this.columns = columns;
            this.error = undefined;
        } else if (error) {
            this.error = error;
            this.items = undefined;
            this.showToast(this.error, 'Error', 'Error'); //show toast for error
        }
    }
 
    handleSave(event){
        const updatedfield = event.detail.draftValues;
            this.saveDraftValue = event.detail.draftValues;
            //alert('updatedfield:'+JSON.stringify(updatedfield));
            //alert('saveDraftValue:'+JSON.stringify(this.saveDraftValue));
    
            updateTask({tskObject :  this.saveDraftValue})
            .then( result =>{
                console.log("apex result:"+JSON.stringify(result))
    
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: result,
                        message: result,
                        variant: 'success'
                    })
                );
                this.saveDraftValue = undefined;
                refreshApex( this.retrievedTask);
            })
            .catch(error=>{
                console.error("err:"+JSON.stringify(error))
               
            })
             
        }
  /*  handleRowAction( event ) {
 
        const actionName = event.detail.action.name;
        const row = event.detail.row;
        switch ( actionName ) {
            case 'view':
                this[NavigationMixin.Navigate]({
                    type: 'standard__recordPage',
                    attributes: {
                        recordId: row.Id,
                        actionName: 'view'
                    }
                });
                break;
            case 'edit':
                this[NavigationMixin.Navigate]({
                    type: 'standard__recordPage',
                    attributes: {
                        recordId: row.Id,
                        objectApiName: 'Task',
                        actionName: 'edit'
                    }
                });
                break;
            default:
        }
    }*/
 
    showToast(message, variant, title) {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
            mode: 'dismissable'
        });
        this.dispatchEvent(event);
    }
 
    handleRowAction(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;
        switch (actionName) {
            case 'view':
                this[NavigationMixin.Navigate]({
                    type: 'standard__recordPage',
                    attributes: {
                        recordId: row.Id,
                        actionName: 'view'
                    }
                });
                break;
            case 'edit':
                this[NavigationMixin.Navigate]({
                    type: 'standard__recordPage',
                    attributes: {
                        recordId: row.Id,
                        objectApiName: 'Task',
                        actionName: 'edit'
                    }
                });
                break;
            default:
        }
 
    }
}